import React from 'react'
import Header from '../common/header/Header'
import Footer from '../common/footer/Footer'

function Dashboard() {
  return (
    <div className="App">
  <Header/>
  <h1>hiii</h1>
  {/* <Footer/> */}
    </div>
  );
}

export default Dashboard;
