import './App.css';
import Dashboard from './dashboard';


function App() {
  return (
    <div className="App">
     <Dashboard/>
    </div>
  );
}

export default App;
