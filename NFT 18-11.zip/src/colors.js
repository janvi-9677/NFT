import { createTheme } from '@material-ui/core/styles';

const Colors =
//  {
//     gray: '#606060',
//     white: '#FFFFFF',
//     skyBlue:'#3393FF'
    
//   };
createTheme({
    palette: {
        pink:'#e57373',
        blue:'rgb(24, 104, 263)',
        black:'#030303'
    },
  });
  
  export default Colors;